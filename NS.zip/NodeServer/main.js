const { initializeApp, applicationDefault, cert } = require('firebase-admin/app');
const { getFirestore, Timestamp, FieldValue } = require('firebase-admin/firestore');
var firebaseConfig = {
    
};
// Initialize Firebase

const serviceAccount = require('./google-service-account.json');

initializeApp({
    credential: cert(serviceAccount)
});

const db = getFirestore();
function getUid(imei) {
    var intimei = parseInt(imei);


    return new Promise(function (resolve, reject) {
        const query = db.collection('imei').where('imei', 'array-contains', intimei);

        // Get the first document in the query results
        query.get().then(async (querySnapshot) => {
            if (!querySnapshot.empty) {
                // If a document was found, get the collection name
                const uid = await querySnapshot.docs[0].ref.id;
                resolve(uid.trim());
            } else {
                reject(2);
            }
        }).catch((error) => {
            reject(error);
        });
    })
}

async function addMessage(imei, body, type) {
    var now = new Date();
    try {
        var bodytemp = body;
        var ifone = JSON.parse(body);
    }
    catch (error) {
        var ifone = {};
        ifone['type'] = 0
    }

    if (ifone['type'] == 0) {
        var bd = (body)
    }
    else {
        var bd = (JSON.parse(body))
    }
    console.log((bd))
    var message = {
        imei: parseInt(imei),
        message: bd,
        timestamp: now.getTime()
    };
    var uid = await getUid(imei).then(function (response) {
        var url = `users/${response}/imei/${imei}/messages`;
        usercoll = db.collection(url).add(message)
        usercoll.then((stat)=>{console.log(stat)})
    });

};




const mqtt = require("mqtt");
const client = mqtt.connect("mqtt://broker.uniolabs.in:1883");
client.on("connect", function () {
    console.log("connected");

    client.subscribe("testing", function (err) { });

    client.on('message', (topic, message) => {
        // console.log(message.toString());
        // console.log('receive message: ', topic, message.toString())
        msg = JSON.parse(message.toString())
        addMessage(msg['imei'], msg['body'], msg['body']['type'])
    })

    client.on("error", (err) => {
        console.log(err);
        clearInterval(interval);
    });
});


