<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Calls</title>
    <link href="https://fonts.googleapis.com/css?family=Lato&display=swap" rel="stylesheet" />
    <!-- <link href="/your-path-to-uicons/css/uicons-rounded-solid.css" rel="stylesheet"> -->
    <link rel='stylesheet' href='https://cdn-uicons.flaticon.com/uicons-regular-straight/css/uicons-regular-straight.css'>
    <link rel='stylesheet' href='<?php echo base_url() ?>assets/css/dashboard.css'>
    <style>
         .white {
            background-color: #FFFFFF !important;
            opacity: 1 !important;
            width: 644px !important;
        }
    </style>
    <!-- <style>
        html {
            width: 100%;
            height: 100%;
        }

        body {
            font-family: 'Lato';
            height: 100%;
            background-repeat: no-repeat;
            background: linear-gradient(148.35deg, #BBD2FF -7.55%, #1A3470 168.79%) fixed;
        }

        .root {
            /* height: 100%;
            display: flex;
            flex-direction: row;
            flex-wrap: wrap;
            gap: 150px */
            display: flex;
            flex-direction: row;
            justify-content: center;
            align-items: center;
            padding: 0px;
            gap: 24px;
        }

        .navbarholder {
            display: flex;
            flex-wrap: wrap;
            align-content: center;
            height: 100%;
            padding-left: 30px;
            /* justify-content: center; */
        }

        .navbar {
            box-sizing: border-box;

            background: #FFFFFF;
            width: 90px;
            height: 390px;
            border: 4px solid #ADB0FF;
            border-radius: 30px;
            display: flex;
            flex-wrap: wrap;
            flex-direction: column;
            justify-content: center;
            align-items: center;
            padding: 0px;
            gap: 36px;
        }

        .main {
            box-sizing: border-box;

            position: absolute;
            width: 644px;
            height: 778px;
            left: 211px;
            top: 105px;

            background: #FFFFFF;
            border: 4px solid #ADB0FF;
            border-radius: 40px;
        }

        .call {
            box-sizing: border-box;

            position: absolute;
            width: 533px;
            height: 778px;
            left: 879px;
            top: 105px;

            background: linear-gradient(179.33deg, #030A1B -3.88%, #420000 108.28%);
            opacity: 0.6;
            border: 4px solid #ADB0FF;
            border-radius: 40px;
        }



        .blhead {
            display: flex;
            flex-direction: row;
            justify-content: left;
            align-items: center;
            margin-top: 20px;
            padding: 0px 2px 0px 20px;
            gap: 130px;
            /* or 25px */

            display: flex;
            letter-spacing: 0.005em;

            color: #242425;
        }

        .blhead_title {
            display: flex;
            flex-direction: row;
            align-items: center;
            padding: 10px 0px;
            gap: 10px;
            color:#575DFB;


            font-family: 'Lato';
            font-style: normal;
            font-weight: 700;
            font-size: 34px;
            line-height: 120%;
        }

        .blhead_addbtn {
            display: flex;
            flex-direction: row;
            justify-content: center;
            align-items: center;
            padding: 0px;
            gap: 8px;
            border-style: none;
            color: #FFFFFF;

            width: 226px;
            height: 40px;

            background: #575DFB;
            border-radius: 12px;

        }

        .line {
            width: 100%;
            height: 0px;
            border: 1px solid #D4DDFF;
            transform: rotate(-0.07deg);
            margin-top: 20px;

        }

        .online {
            font-family: 'Lato';
            font-style: normal;
            font-weight: 400;
            font-size: 14px;
            line-height: 110%;
            padding-top: 10px;
            padding-left: 50px;
            /* or 15px */

            display: flex;
            align-items: center;
            letter-spacing: 0.005em;

            color: #4D4D4D;
        }
    </style> -->
    
</head>

<body>

    <div class="root">
        <?php
        $data = ['active' => "calls"];
        $this->load->view('components/navbar', $data); ?>
        <div class="main">

            <div class="right white">
                <div class="blhead">
                    <div class="blhead_title">
                        Contacts
                    </div>
                    <button class="blhead_addbtn">+ Add Contacts</button>
                </div>
                <div class="line"></div>
                <div class="online">{#} Contacts</div>
            </div>
            <div class="right call"></div>
        </div>
    </div>
</body>

</html>