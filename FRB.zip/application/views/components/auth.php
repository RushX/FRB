<script src="https://www.gstatic.com/firebasejs/8.0.1/firebase-app.js"></script>

<script src="https://www.gstatic.com/firebasejs/8.0.0/firebase-auth.js"></script>

<script>
    var firebaseConfig = {
    };
    // Initialize Firebase
    firebase.initializeApp(firebaseConfig);

    // document.getElementById('logout').addEventListener('click', LogoutUser)

    let provider = new firebase.auth.GoogleAuthProvider()


    function showUserDetails() {
        firebase.auth().onAuthStateChanged(user => {
            if (user) {
                document.getElementById('user_name').innerHTML = user.displayName
                document.getElementById('user_email').innerHTML = user.email
            } else {
                window.location = ("<?php echo base_url()?>login")

            }
        })
    }

    function checkAuthState() {
        firebase.auth().onAuthStateChanged(user => {
            if (user) {
                // showUserDetails(user)
            } else {
                window.location = ("<?php echo base_url()?>login")

            }
        })
    }

    function logoutUser() {
        console.log('Logout Btn Call')
        firebase.auth().signOut().then(() => {}).catch(e => {
            console.log(e)
        })
    }
    checkAuthState()
</script>